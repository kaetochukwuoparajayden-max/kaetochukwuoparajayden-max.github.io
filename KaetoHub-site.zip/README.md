# KaetoHub

A static website with:
- Google search
- Tic-Tac-Toe
- Snake
- Click Rush
- A starter AI assistant

## Publish it as a real website

The easiest free option is GitHub Pages.

1. Create a GitHub account.
2. Create a **public** repository named `YOUR-USERNAME.github.io`.
3. Upload `index.html` from this folder.
4. Open the repository's **Settings → Pages**.
5. Set the publishing source to your main branch.
6. Your site will be available at `https://YOUR-USERNAME.github.io`.

You can later connect a custom domain such as `kaetohub.com`.

## Google

After the site is public, submit the site in Google Search Console and request indexing. Google does not guarantee that a new site will appear immediately.

## Important

The included AI is a browser demo. A real AI API key should NOT be placed directly in `index.html`; it should be called through a secure server/backend.
